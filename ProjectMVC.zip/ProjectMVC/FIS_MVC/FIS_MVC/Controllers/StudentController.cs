﻿using FIS_MVC.Models;
using FIS_MVC.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace FIS_MVC.Controllers
{
    public class StudentController : Controller
    {
        private FIS_Context Context = new FIS_Context();
        // GET: Student
        public ActionResult StudentHome(string message)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            ViewBag.msg = message;
            return View();
        }

        public ActionResult Search()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            try
            {
                ViewBag.Choices = Context.Faculties.ToList();

                ViewBag.Status = 1;
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return View();
        }
        [HttpPost]
        public ActionResult Search(string FacultyID)
        {
            try
            {
                ViewBag.Choices = Context.Faculties.ToList();

                List<Publication> lstpublication = new List<Publication>();
                if (FacultyID != "Select Faculty")
                {
                    int facultyID = Convert.ToInt32(FacultyID);
              
                    lstpublication = Context.Publications.Where(x => x.FacultyID == facultyID).ToList();
                    if (lstpublication.Count == 0)
                    {
                        ViewBag.Status = 1;

                    }
                    else
                    {
                        ViewBag.Publicationlst = lstpublication;
                    }
                }
                else
                {
                    string msg = "Faculty Not Found";
                   // ViewBag.msg = "something went wrong!";
                    return RedirectToAction("StudentHome", new { message = msg });

                }
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return View();
        }
       
    }
}