﻿using FIS_MVC.Models;
using FIS_MVC.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FIS_MVC.Controllers
{
    public class AccountController : Controller
    {
        private FIS_Context Context = new FIS_Context();
        // GET: Account
     
        public ActionResult Login(User user)
        {
            ModelState.Clear();
            if (user.username != null && user.password!=null)
            {
                User userDetail = Context.Users.Where(x => x.username == user.username && x.password == user.password).FirstOrDefault();
                if (userDetail != null)
                {
                    Log.Info("User Logged in Username is"+""+userDetail.username);
                    Session["UserName"] = userDetail.username.ToString();
                    if (userDetail.usertype == "Student")
                    {
                        return RedirectToAction("StudentHome", "Student");
                    }
                    else if (userDetail.usertype == "Admin")
                    { return RedirectToAction("AdminHome", "Admin"); }
                    else if (userDetail.usertype == "Faculty")
                    { return RedirectToAction("FacultyHome", "Faculty"); }


                }
                else
                {
                    ViewBag.SuccessfullMsg = "Username or Password is Invalid";
                    return View();
                }
            }
            return View();
        }
        public ActionResult LogOut()
        {
            Session["UserName"] = null;
            Session.Abandon();
            Session.Clear();
            return RedirectToAction("Login");
            

        }

    }
}