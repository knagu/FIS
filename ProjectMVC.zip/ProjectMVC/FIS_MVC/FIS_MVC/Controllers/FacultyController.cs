﻿using FIS_MVC.Models;
using FIS_MVC.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FIS_MVC.Controllers
{
    public class FacultyController : Controller
    {
        private FIS_Context Context = new FIS_Context();
        // GET: Faculty
        public ActionResult FacultyHome(string message)
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");

                }
                string username = Session["UserName"].ToString();
                ViewBag.SuccessfullMsg = message;
                int FacultyId = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();
                if (FacultyId == 0)
                {
                    return RedirectToAction("ViewPersonalInfo");
                }
                else
                {
                    return View();
                }
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
        }
        public ActionResult ViewWorkHistory()
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");
                }
                string username = Session["UserName"].ToString();
                int FacultyId = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();
                WorkHistory workHistory = Context.WorkHistories.Where(x => x.FacultyID == FacultyId).FirstOrDefault();

                if (workHistory != null)
                {
                    return View(workHistory);
                }

                else
                {
                    ViewBag.Errormsg = "No Work History Exist.Add Work History!!";
                    return View();
                }
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
        }
        public ActionResult AddWorkHistory()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }

            return View();
        }
        [HttpPost]
        public ActionResult AddWorkHistory(WorkHistory workHistory)
        {
            string msg;
            try
            {
                string username = Session["UserName"].ToString();
                workHistory.FacultyID = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();

                WorkHistory workHistoryToBeAdded = Context.WorkHistories.Where(x => x.FacultyID == workHistory.FacultyID).FirstOrDefault();
                if (workHistoryToBeAdded == null)
                {
                    Context.WorkHistories.Add(workHistory);
                    Context.SaveChanges();
                    msg = "Work Information Successfully Added..!!";
                }
                else
                {
                    msg = "Work Information Already Exist in database";
                }
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return RedirectToAction("ViewWorkHistory", new { message = msg });
        }
        public ActionResult UpdateWorkHistory(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            WorkHistory workHistoryToBeUpdated = Context.WorkHistories.Where(x => x.WorkHistoryID == id).FirstOrDefault();

            return View(workHistoryToBeUpdated);
        }
        [HttpPost]
        public ActionResult UpdateWorkHistory(WorkHistory workHistory)
        {
            string msg;
            try
            {
                WorkHistory workHistoryToBeUpdated = Context.WorkHistories.Where(x => x.WorkHistoryID == workHistory.WorkHistoryID).FirstOrDefault();
                string username = Session["UserName"].ToString();

                workHistoryToBeUpdated.FacultyID = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();
                workHistoryToBeUpdated.Organization = workHistory.Organization;
                workHistoryToBeUpdated.JobTitle = workHistory.JobTitle;
                workHistoryToBeUpdated.JobBeginDate = workHistory.JobBeginDate;
                workHistoryToBeUpdated.JobEndDate = workHistory.JobEndDate;
                workHistoryToBeUpdated.JobResponsibilities = workHistory.JobResponsibilities;
                workHistoryToBeUpdated.JobType = workHistory.JobType;
                Context.SaveChanges();

                msg = "Work Information Successfully Updated..!!";
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return RedirectToAction("ViewWorkHistory", new { message = msg });
        }

        public ActionResult DeleteWorkHistory(int? id)
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");

                }
                WorkHistory workHistoryToBeDeleted = Context.WorkHistories.Where(x => x.WorkHistoryID == id).FirstOrDefault();
                Context.WorkHistories.Remove(workHistoryToBeDeleted);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            string msg = "Work History Successfully Deleted..!!";

            return RedirectToAction("ViewWorkHistory", new { message = msg });
        }
        public ActionResult ViewPublications(string message)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            ViewBag.SuccessfullMsg = message;
            string username = Session["UserName"].ToString();
            int FacultyId = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();
            List<Publication> publicationList = Context.Publications.Where(x => x.FacultyID == FacultyId).ToList();

            return View(publicationList);
        }
        public ActionResult AddPublications()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }

            return View();
        }

        [HttpPost]
   
        public ActionResult AddPublications(Publication publication)
        {
            string msg;
            try
            {
                string username = Session["UserName"].ToString();
                publication.FacultyID = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();

                Context.Publications.Add(publication);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            msg = "Publication Information Successfully Added..!!";


            return RedirectToAction("ViewPublications", new { message = msg });
        }
        public ActionResult UpdatePublications(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            Publication publication = Context.Publications.Where(x => x.PublicationID == id).FirstOrDefault();

            return View(publication);
        }

        [HttpPost]
        public ActionResult UpdatePublications(Publication publication)
        {
            string msg;
            try
            {
                Publication publicationToBeUpdated = Context.Publications.Where(x => x.PublicationID == publication.PublicationID).FirstOrDefault();
                publicationToBeUpdated.PublicationTitle = publication.PublicationTitle;
                publicationToBeUpdated.PublisherName = publication.PublisherName;
                publicationToBeUpdated.ArticleName = publication.ArticleName;
                publicationToBeUpdated.PublicationLocation = publication.PublicationLocation;
                publicationToBeUpdated.CitationDate = publication.CitationDate;

                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            msg = "Publication Information Successfully Updated..!!";


            return RedirectToAction("ViewPublications", new { message = msg });
        }

        public ActionResult DeletePublications(int? id)
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");

                }
                Publication publication = Context.Publications.Where(x => x.PublicationID == id).FirstOrDefault();
                Context.Publications.Remove(publication);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            string msg = "Publication Successfully Deleted..!!";


            return RedirectToAction("ViewPublications", new { message = msg });
        }



        public ActionResult ViewPersonalInfo(string message)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            ViewBag.SuccessfullMsg = message;
            string username = Session["UserName"].ToString();
            Faculty personalInfo = Context.Faculties.Where(x => x.UserName == username).FirstOrDefault();
            if (personalInfo != null)
            {
                return View(personalInfo);
            }

            else
            {
                ViewBag.Errormsg = "No Personal Information Exist.Add Your Information!!";


                return View();

            }
        }

        public ActionResult AddPersonalInfo()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }

            return View();
        }
       
        [HttpPost]
        public ActionResult AddPersonalInfo(Faculty faculty)
        {
            string msg;
            try
            {
                faculty.UserName = Session["UserName"].ToString();
                Faculty PersonalInfoToBeAdded = Context.Faculties.Where(x => x.FacultyID == faculty.FacultyID).FirstOrDefault();
                if (PersonalInfoToBeAdded == null)
                {

                    Context.Faculties.Add(faculty);
                    Context.SaveChanges();
                    msg = "Faculty Information Successfully Added..!!";
                }
                else
                {
                    msg = "Faculty Information Already Exist in database";
                }
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return RedirectToAction("ViewPersonalInfo", new { message = msg });
        }

        public ActionResult UpdatePersonalInfo(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            Faculty PersonalInfoToBeUpdated = Context.Faculties.Where(x => x.FacultyID == id).FirstOrDefault();


            return View(PersonalInfoToBeUpdated);
        }

        [HttpPost]
        public ActionResult UpdatePersonalInfo(Faculty faculty)
        {
            string msg;
            try
            {
                Faculty PersonalInfoToBeUpdated = Context.Faculties.Where(x => x.FacultyID == faculty.FacultyID).FirstOrDefault();
                PersonalInfoToBeUpdated.FirstName = faculty.FirstName;
                PersonalInfoToBeUpdated.LastName = faculty.LastName;
                PersonalInfoToBeUpdated.Address = faculty.Address;
                PersonalInfoToBeUpdated.City = faculty.City;
                PersonalInfoToBeUpdated.State = faculty.State;
                PersonalInfoToBeUpdated.Pincode = faculty.Pincode;
                PersonalInfoToBeUpdated.MobileNo = faculty.MobileNo;
                PersonalInfoToBeUpdated.HireDate = faculty.HireDate;
                PersonalInfoToBeUpdated.EmailAddress = faculty.EmailAddress;
                PersonalInfoToBeUpdated.DateofBirth = faculty.DateofBirth;
                PersonalInfoToBeUpdated.DeptID = faculty.DeptID;
                PersonalInfoToBeUpdated.DesignationID = faculty.DesignationID;


                Context.SaveChanges();
                msg = "Faculty Information Successfully Updated..!!";
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return RedirectToAction("ViewPersonalInfo", new { message = msg });
        }
        public ActionResult DeletePersonalInfo(int? id)
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");

                }
                WorkHistory workHistoryToBeDeleted = Context.WorkHistories.Where(x => x.FacultyID == id).FirstOrDefault();
                if (workHistoryToBeDeleted != null)
                {
                    Context.WorkHistories.Remove(workHistoryToBeDeleted);
                    Context.SaveChanges();
                }
                Faculty PersonalInfoToBeDeleted = Context.Faculties.Where(x => x.FacultyID == id).FirstOrDefault();
                Context.Faculties.Remove(PersonalInfoToBeDeleted);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            string msg = "Faculty Information Successfully Deleted..!!";

            return RedirectToAction("ViewPersonalInfo", new { message = msg });
        }

        public ActionResult ViewGrantInformation(string message)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            ViewBag.SuccessfullMsg = message;
            string username = Session["UserName"].ToString();
            int FacultyId = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();
            List<Grant> grantsList = Context.Grants.Where(x => x.FacultyID == FacultyId).ToList();

            return View(grantsList);
        }
        public ActionResult AddGrantInformation()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }


            return View();
        }
        [HttpPost]
        public ActionResult AddGrantInformation(Grant grant)
        {
            string username = Session["UserName"].ToString();
            string msg;
            try
            {
                int facultyid = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();

                grant.FacultyID = facultyid;
                Context.Grants.Add(grant);
                Context.SaveChanges();
                msg = "Grant Information Successfully Added..!!";
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return RedirectToAction("ViewGrantInformation", new { message = msg });





        }
        public ActionResult UpdateGrantInformation(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            Grant grant = Context.Grants.Where(x => x.GrantID == id).FirstOrDefault();

            return View(grant);
        }
        [HttpPost]
        public ActionResult UpdateGrantInformation(Grant grant)
        {
            try
            {
                Grant grantToBeUpdated = Context.Grants.Where(x => x.GrantID == grant.GrantID).FirstOrDefault();

                grantToBeUpdated.GrantTitle = grant.GrantTitle;
                grantToBeUpdated.GrantDescription = grant.GrantDescription;

                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            string msg = "Grant Information Successfully Updated..!!";
            return RedirectToAction("ViewGrantInformation", new { message = msg });
        }
        public ActionResult DeleteGrantInformation(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            try
            {
                Grant grant = Context.Grants.Where(x => x.GrantID == id).FirstOrDefault();
                Context.Grants.Remove(grant);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            string msg = "Grant Information Successfully Deleted..!!";
            return RedirectToAction("ViewGrantInformation", new { message = msg });
        }
        public ActionResult ViewCourseTaughts(string message)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            ViewBag.SuccessfullMsg = message;
            string username = Session["UserName"].ToString();
            int FacultyId = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();
            List<CoursesTaught> courseTaughtList = Context.CoursesTaughts.Where(x => x.FacultyID == FacultyId).ToList();

            return View(courseTaughtList);
        }

        public ActionResult AddCourseTaught()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }


            return View();
        }
        [HttpPost]
        public ActionResult AddCourseTaught(CoursesTaught coursesTaught)
        {
            try
            {
                string username = Session["UserName"].ToString();
                coursesTaught.FacultyID = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();
                Context.CoursesTaughts.Add(coursesTaught);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            string msg = "Course Taught Successfully Added..!!";


            return RedirectToAction("ViewCourseTaughts", new { message = msg });
        }
        public ActionResult UpdateCourseTaught(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            CoursesTaught coursesTaught = Context.CoursesTaughts.Where(x => x.CourseTaughtID == id).FirstOrDefault();

            return View(coursesTaught);
        }
        [HttpPost]
        public ActionResult UpdateCourseTaught(CoursesTaught coursesTaught)
        {
            try
            {
                CoursesTaught courseTaughtToBeUpdated = Context.CoursesTaughts.Where(x => x.CourseTaughtID == coursesTaught.CourseTaughtID).FirstOrDefault();
                courseTaughtToBeUpdated.CourseID = coursesTaught.CourseID;

                string username = Session["UserName"].ToString();
                courseTaughtToBeUpdated.FacultyID = Context.Faculties.Where(x => x.UserName == username).Select(x => x.FacultyID).FirstOrDefault();

                courseTaughtToBeUpdated.SubjectID = coursesTaught.SubjectID;
                courseTaughtToBeUpdated.FirstDateTaught = coursesTaught.FirstDateTaught;

                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            string msg = "Course Taught Successfully Updated..!!";


            return RedirectToAction("ViewCourseTaughts", new { message = msg });
        }
        public ActionResult DeleteCourseTaught(int? id)
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");

                }
                else
                {
                    CoursesTaught coursesTaught = Context.CoursesTaughts.Where(x => x.CourseTaughtID == id).FirstOrDefault();
                    Context.CoursesTaughts.Remove(coursesTaught);
                    Context.SaveChanges();
                    string msg = "Course Taught Successfully Deleted..!!";


                    return RedirectToAction("ViewCourseTaughts", new { message = msg });
                }
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
        }



    }
}