﻿using FIS_MVC.Models;
using FIS_MVC.Utilities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace FIS_MVC.Controllers
{
    public class AdminController : Controller
    {
        private FIS_Context Context = new FIS_Context();

        // GET: Admin
        public ActionResult AdminHome(string message)
        {

            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            ViewBag.SuccessfullMsg = message;
            return View();
        }
        public ActionResult Create()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            return View();
        }
        [HttpPost]
        public ActionResult Create(User user)
        {
            string msg;
            try
            {
                if (user.usertype != "select")
                {
                    Context.Users.Add(user);
                    Context.SaveChanges();
                    msg = "User Successfully Added..!!";
                }
                else
                {
                    ViewBag.msg = "*Select UserType";
                    return View();
                }
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return RedirectToAction("AdminHome", new { message = msg });
        }
        public ActionResult ViewDepartment(string message)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            List<Department> departmentList = Context.Departments.ToList();

            ViewBag.Message = message;
            return View(departmentList);
        }
        public ActionResult AddDepartment()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            return View();
        }
        [HttpPost]
       
        public ActionResult AddDepartment(Department department)
        {
            string msg = null;
            Context.Departments.Add(department);
            try
            {
                 Context.SaveChanges();
                 msg = "Department Successfully Added..!!";
            }
            catch(Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return RedirectToAction("AdminHome", new { message = msg });
        }
        public ActionResult ViewCourses()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");
            }
            List<Course> coursesList = Context.Courses.ToList();

            return View(coursesList);
        }
        [MyErrorHandler]
        // [CustomExceptionFilter]
        public ActionResult AddCourse()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            return View();
        }
        [HttpPost]
        public ActionResult AddCourse(Course course)
        {
            try
            {
                Context.Courses.Add(course);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return RedirectToAction("ViewCourses");
        }
        public ActionResult UpdateCourse(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            Course courseToBeUpdated = Context.Courses.Where(x => x.CourseID == id).FirstOrDefault();
            return View(courseToBeUpdated);
        }
        [HttpPost]
        public ActionResult UpdateCourse(Course course)
        {
            try
            {
                Course courseToBeUpdated = Context.Courses.Where(x => x.CourseID == course.CourseID).FirstOrDefault();
                courseToBeUpdated.CourseName = course.CourseName;
                courseToBeUpdated.DeptID = course.DeptID;
                courseToBeUpdated.CourseCredits = course.CourseCredits;
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return RedirectToAction("ViewCourses");
        }
        public ActionResult DeleteCourse(int? id)
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");

                }
                var coursesTaught = Context.CoursesTaughts.Where(x => x.CourseID == id);


                if (coursesTaught != null)
                {
                    Context.CoursesTaughts.RemoveRange(coursesTaught);
                    Context.SaveChanges();
                }
                Course courseToBeDeleted = Context.Courses.Where(x => x.CourseID == id).FirstOrDefault();
                Context.Courses.Remove(courseToBeDeleted);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }
            return RedirectToAction("ViewCourses");
        }

        public ActionResult ViewSubjects()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            List<Subject> subjectsList = Context.Subjects.ToList();

            return View(subjectsList);
        }

        public ActionResult AddSubject()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            return View();
        }
        [HttpPost]
        public ActionResult AddSubject(Subject subject)
        {
            try
            {
                Context.Subjects.Add(subject);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return RedirectToAction("ViewSubjects");
        }
        public ActionResult UpdateSubject(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            Subject subjectToBeUpdated = Context.Subjects.Where(x => x.SubjectID == id).FirstOrDefault();
            return View(subjectToBeUpdated);
        }
        [HttpPost]
        public ActionResult UpdateSubject(Subject subject)
        {
            try
            {
                Subject subjectToBeUpdated = Context.Subjects.Where(x => x.SubjectID == subject.SubjectID).FirstOrDefault();
                subjectToBeUpdated.SubjectName = subject.SubjectName;
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return RedirectToAction("ViewSubjects");
        }
        public ActionResult DeleteSubject(int? id)
        {
            try
            {
                if (Session["UserName"] == null)
                {
                    return RedirectToAction("Login", "Account");

                }
                var coursesTaught = Context.CoursesTaughts.Where(x => x.SubjectID == id);
                if (coursesTaught != null)
                {
                    Context.CoursesTaughts.RemoveRange(coursesTaught);
                    Context.SaveChanges();
                }
                Subject subjectToBeDeleted = Context.Subjects.Where(x => x.SubjectID == id).FirstOrDefault();
                Context.Subjects.Remove(subjectToBeDeleted);
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return RedirectToAction("ViewSubjects");
        }
        public ActionResult ViewFacultyWorkHistory(string message)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            List<WorkHistory> facultyList = Context.WorkHistories.ToList();

            ViewBag.Message = message;
            return View(facultyList);
        }
        public ActionResult UpdateWorkInformation(int? id)
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }
            WorkHistory workHistoryToBeUpdated = Context.WorkHistories.Where(x => x.FacultyID == id).FirstOrDefault();
            if (workHistoryToBeUpdated != null)
            {
                return View(workHistoryToBeUpdated);
            }
            else
            {
                string Msg = "Work History Not available";
                return RedirectToAction("ViewAllFaculty", new { message = Msg });
            }
        }
        [HttpPost]
        public ActionResult UpdateWorkInformation(WorkHistory workHistory)
        {
            try
            {
                WorkHistory workHistoryToBeUpdated = Context.WorkHistories.Where(x => x.FacultyID == workHistory.FacultyID).FirstOrDefault();
                workHistoryToBeUpdated.Organization = workHistory.Organization;
                workHistoryToBeUpdated.JobTitle = workHistory.JobTitle;
                workHistoryToBeUpdated.JobBeginDate = workHistory.JobBeginDate;
                workHistoryToBeUpdated.JobEndDate = workHistory.JobEndDate;
                workHistoryToBeUpdated.JobResponsibilities = workHistory.JobResponsibilities;
                workHistoryToBeUpdated.JobType = workHistory.JobType;
                Context.SaveChanges();
            }
            catch (Exception ex)
            {
                Log.Info("Exception Occured....", ex);
                ViewBag.msg = "something went wrong!";
                return View();
            }

            return RedirectToAction("ViewFacultyWorkHistory");
        }
        public ActionResult ViewPublications()
        {
            if (Session["UserName"] == null)
            {
                return RedirectToAction("Login", "Account");

            }

            List<Publication> publicationList = Context.Publications.ToList();


                return View(publicationList);
         
        }
    }
}