﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FIS_MVC.Models
{


    public class MyErrorHandler : FilterAttribute, IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            Log(filterContext.Exception);
            filterContext.Result = new RedirectResult("/Error/Index");
             filterContext.ExceptionHandled = true;
          //  throw new NotImplementedException();
        }

        public  void Log(Exception exception)
        {
            //log exception here..

            var filename = AppDomain.CurrentDomain.BaseDirectory + "App_Data\\" + "Error.txt";
            var sw = new System.IO.StreamWriter(filename, true);
            sw.WriteLine(DateTime.Now.ToString() + " " + exception.Message + " " + exception.InnerException);
            sw.Close();
            
        }
       
    }

    //public class CustomExceptionFilter : FilterAttribute,IExceptionFilter
    //{
    //    public void OnException(ExceptionContext filterContext)
    //    {
    //        if (!filterContext.ExceptionHandled && filterContext.Exception is SqlException)
    //        {
    //            filterContext.Result = new RedirectResult("FacultyHome.cshtml");
    //            filterContext.ExceptionHandled = true;
    //        }
    //    }
    //}
}