﻿using FISEntity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FISDAL
{
    public class UserDAL
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(ConnectionString);
        SqlCommand command;
        public bool GetUserPassword(UserEntity user)
        {
            bool IsPasswordMatch = false;

            try
            {
                string query = "[FIS_14_NOV].[usp_UserLogin]";
                command = new SqlCommand(query, connection);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();

                command.Parameters.AddWithValue("@UserName", user.UserName);
                command.Parameters.AddWithValue("@UserType", user.UserType);

                connection.Open();
                object RetrievedPassword = command.ExecuteScalar();

                if (RetrievedPassword != null && RetrievedPassword.ToString() == user.Password)
                {
                    IsPasswordMatch = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (FISException.FISException Exception)
            {
                throw Exception;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return IsPasswordMatch;
        }


    }
}
