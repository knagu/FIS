﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FISDAL
{
   public class StudentDAL
    {
       static string connectionstring = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_14Nov18_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
        SqlConnection conn = new SqlConnection(connectionstring);
        public DataSet GetFacultyNameDAL()
        {
            DataSet ds = new DataSet();
            try
            {
                SqlCommand command = new SqlCommand("[FIS_14_NOV].[usp_GetFacultyName]", conn);
                command.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(command);

                da.Fill(ds, "usertable");
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
            return ds;
        }


        public DataSet GetPublicationTitleDAL(string selectedvalue)
        {
           
            SqlCommand command = new SqlCommand("[FIS_14_NOV].[usp_GetPublicationTitle]", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@FacultyId", selectedvalue);
            SqlDataAdapter da = new SqlDataAdapter(command);
            DataSet ds = new DataSet();
            da.Fill(ds, "usertable");
            return ds;
        }
        public DataTable ShowPublicationDAL(string selectedvalue)
        {
            SqlCommand command = new SqlCommand("[FIS_14_NOV].[usp_GetPublicationforStudent]", conn);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@PublicationId", selectedvalue);
            conn.Open();
            SqlDataReader reader = command.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            conn.Close();
            return dataTable;
        }
    }
}
