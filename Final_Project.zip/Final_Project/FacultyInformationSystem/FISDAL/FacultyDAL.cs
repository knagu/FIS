﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FISEntity;
using FISException;

namespace FISDAL
{
    public class FacultyDAL
    {

        //creating Gobal Objects
        SqlConnection connection;
        SqlCommand command;

        public FacultyDAL()
        {
            connection = new SqlConnection();
            command = new SqlCommand();

            //establishing connection with data base
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            command.Connection = connection;
        }

        public int GetFacultyIdDAL(string userName)
        {
            FacultyEntity ObjTempFaculty = new FISEntity.FacultyEntity();
            int Id = 0;
            try
            {
                command.CommandText = "[FIS_14_NOV].[usp_GetfacultyId]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@userName", userName);
                connection.Open();
                object result = command.ExecuteScalar();
                Id = Convert.ToInt32(result);
               // connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return Id;
        }


        public  bool AddFacultyDAL(FacultyEntity newFaculty)
        {
            bool facultyAdded = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_InsertFaculty";
                command.CommandType = CommandType.StoredProcedure;



                command.Parameters.Clear();
                command.Parameters.AddWithValue("@UserName", newFaculty.UserName);
                command.Parameters.AddWithValue("@FirstName", newFaculty.FirstName);
                command.Parameters.AddWithValue("@LastName", newFaculty.LastName);
                command.Parameters.AddWithValue("@Address", newFaculty.Address);
                command.Parameters.AddWithValue("@City", newFaculty.City);
                command.Parameters.AddWithValue("@State", newFaculty.State);
                command.Parameters.AddWithValue("@Pincode", newFaculty.Pincode);
                command.Parameters.AddWithValue("@MobileNo", newFaculty.MobileNo);
                command.Parameters.AddWithValue("@HireDate", newFaculty.HireDate);
                command.Parameters.AddWithValue("@EmailAddress", newFaculty.EmailAddress);
                command.Parameters.AddWithValue("@DateOfBirth", newFaculty.DateOfBirth);
                command.Parameters.AddWithValue("@DeptId", newFaculty.DeptID);
                command.Parameters.AddWithValue("@DesignationId", newFaculty.DesignationID);
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                if (NoOfRowsAffected == 1)
                {
                    facultyAdded = true;
                }
                
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return facultyAdded;
        }
        public DataTable GetAllFacultyDAL(string userName)
        {
            FacultyEntity ObjTempFaculty = new FISEntity.FacultyEntity();
            DataTable table = new DataTable();
            try
            {
                SqlDataReader reader;
                command.CommandText = "FIS_14_NOV.usp_ViewFaculty";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@userName", userName);
                connection.Open();
                reader = command.ExecuteReader();
               
                table.Load(reader);
                
               
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }

        public  bool DeleteFacultyDAL(int deleteFacultyID)
        {
            bool facultyDeleted = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_DeleteFaculty";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@FacultyId", deleteFacultyID);

                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();
                //connection.Close();
                if (NoOfRowsAffected == 1)
                    facultyDeleted = true;

            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return facultyDeleted;

        }


        public FISEntity.FacultyEntity SearchFacultyDAL(int searchFacultyID,string userName)
        {
            FISEntity.FacultyEntity searchFaculty = null;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_SearchFaculty";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@FacultyId", searchFacultyID);

                SqlDataReader reader;
                connection.Open();
                
                reader = command.ExecuteReader();
                
                    if (reader.HasRows)
                     {
                    while (reader.Read())
                    {
                        if (userName == reader.GetString(1))
                        {
                            searchFaculty = new FISEntity.FacultyEntity();
                            searchFaculty.FacultyID = reader.GetInt32(0);
                            searchFaculty.UserName = reader.GetString(1);
                            searchFaculty.FirstName = reader.GetString(2);
                            searchFaculty.LastName = reader.GetString(3);
                            searchFaculty.Address = reader.GetString(4);
                            searchFaculty.City = reader.GetString(5);
                            searchFaculty.State = reader.GetString(6);
                            searchFaculty.Pincode = reader.GetInt32(7);
                            searchFaculty.MobileNo = Convert.ToInt64(reader[8]);
                            searchFaculty.HireDate = reader.GetDateTime(9);
                            searchFaculty.EmailAddress = reader.GetString(10);
                            searchFaculty.DateOfBirth = reader.GetDateTime(11);
                            searchFaculty.DeptID = reader.GetInt32(12);
                            searchFaculty.DesignationID = reader.GetInt32(13);
                    }
                 }
                }
                reader.Close();
                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return searchFaculty;
        }

        public bool UpdateFacultyDAL(FISEntity.FacultyEntity updateFaculty)
        {
            bool facultyUpdated = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_UpdateFaculty";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@FacultyID", updateFaculty.FacultyID);
                command.Parameters.AddWithValue("@UserName", updateFaculty.UserName);
                command.Parameters.AddWithValue("@FirstName", updateFaculty.FirstName);
                command.Parameters.AddWithValue("@LastName", updateFaculty.LastName);
                command.Parameters.AddWithValue("@Address", updateFaculty.Address);
                command.Parameters.AddWithValue("@City", updateFaculty.City);
                command.Parameters.AddWithValue("@State", updateFaculty.State);
                command.Parameters.AddWithValue("@Pincode", updateFaculty.Pincode);
                command.Parameters.AddWithValue("@MobileNo", updateFaculty.MobileNo);
                command.Parameters.AddWithValue("@HireDate", updateFaculty.HireDate);
                command.Parameters.AddWithValue("@EmailAddress", updateFaculty.EmailAddress);
                command.Parameters.AddWithValue("@DateOfBirth", updateFaculty.DateOfBirth);
                command.Parameters.AddWithValue("@DeptId", updateFaculty.DeptID);
                command.Parameters.AddWithValue("@DesignationId", updateFaculty.DesignationID);

                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();
               // connection.Close();
                if (NoOfRowsAffected == 1)
                       facultyUpdated =true;
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return facultyUpdated;

        }



        //CURD operations for Publication
        public bool AddPublicationDAL(PublicationsEntity publications)
        {
            bool isAdded = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_AddPublications";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@FacultyID", publications.FacultyID);
                command.Parameters.AddWithValue("@PublicationTitle", publications.PublicationTitle);
                command.Parameters.AddWithValue("@ArticleName", publications.ArticleName);
                command.Parameters.AddWithValue("@PublisherName", publications.PublisherName);
                command.Parameters.AddWithValue("@PublicationLocation", publications.PublicationLocation);
                command.Parameters.AddWithValue("@CitationDate", publications.CitationDate);

                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }
        public DataTable GetAllPublicationsDAL(int facultyID)
        {
            DataTable table = new DataTable();
            try
            {
                SqlDataReader reader;
                command.CommandText = "[FIS_14_NOV].[usp_ViewPublications]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@facultyID", facultyID);
                connection.Open();
                reader = command.ExecuteReader();

                table.Load(reader);

                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }

        public bool UpdatePublicationDAL(PublicationsEntity publications)
        {
            bool isUpdate = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_UpdatePublications";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();
                command.Parameters.AddWithValue("@PublicationID", publications.PublicationID);
                command.Parameters.AddWithValue("@FacultyID", publications.FacultyID);
                command.Parameters.AddWithValue("@PublicationTitle", publications.PublicationTitle);
                command.Parameters.AddWithValue("@ArticleName", publications.ArticleName);
                command.Parameters.AddWithValue("@PublisherName", publications.PublisherName);
                command.Parameters.AddWithValue("@PublicationLocation", publications.PublicationLocation);
                command.Parameters.AddWithValue("@CitationDate", publications.CitationDate);
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }
        public bool DeletePublications(int PublicationID)
        {
            bool isDelete = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_DeletePublications";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@PublicationID", PublicationID);

                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }

        public PublicationsEntity SearchPublicationsDAL(int PublicationID)
        {
            PublicationsEntity searchPublication = null;
            try
            {
                command.CommandText = "[FIS_14_NOV].[usp_SearchPublication]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@PublicationID", PublicationID);

                SqlDataReader ObjSqlDataReader;
                connection.Open();
                ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    while (ObjSqlDataReader.Read())
                    {
                        searchPublication = new PublicationsEntity();
                        searchPublication.PublicationID = ObjSqlDataReader.GetInt32(0);
                        searchPublication.FacultyID = ObjSqlDataReader.GetInt32(1);
                        searchPublication.PublicationTitle = ObjSqlDataReader.GetString(2);
                        searchPublication.ArticleName = ObjSqlDataReader.GetString(3);
                        searchPublication.PublisherName = ObjSqlDataReader.GetString(4);
                        searchPublication.PublicationLocation = ObjSqlDataReader.GetString(5);
                        searchPublication.CitationDate = ObjSqlDataReader.GetDateTime(6);
                    }
                }
                ObjSqlDataReader.Close();
               // connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return searchPublication;
        }


        //CURD Operations for Work History
        public bool AddWorkHistoryDAL(WorkHistory workHistory)
        {
            bool isAdded = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_AddWorkHistory";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();
                
                command.Parameters.AddWithValue("@FacultyID", workHistory.FacultyID);
                command.Parameters.AddWithValue("@Organization", workHistory.Organization);
                command.Parameters.AddWithValue("@JobTitle", workHistory.JobTitle);
                command.Parameters.AddWithValue("@JobBeginDate", workHistory.JobBeginDate);
                command.Parameters.AddWithValue("@JobEndDate", workHistory.JobEndDate);
                command.Parameters.AddWithValue("@JobResponsibilities", workHistory.JobResponsibilities);
                command.Parameters.AddWithValue("@JobType", workHistory.JobType);
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }
        public bool UpdateWorkHistory(WorkHistory workHistory)
        {
            bool isUpdate = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_UpdateWorkHistory";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@WorkHistoryID", workHistory.WorkHistoryID);
                command.Parameters.AddWithValue("@FacultyID", workHistory.FacultyID);
                command.Parameters.AddWithValue("@Organization", workHistory.Organization);
                command.Parameters.AddWithValue("@JobTitle", workHistory.JobTitle);
                command.Parameters.AddWithValue("@JobBeginDate", workHistory.JobBeginDate);
                command.Parameters.AddWithValue("@JobEndDate", workHistory.JobEndDate);
                command.Parameters.AddWithValue("@JobResponsibilities", workHistory.JobResponsibilities);
                command.Parameters.AddWithValue("@JobType", workHistory.JobType);
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }
        public bool DeleteWorkHistory(int WorkHistoryID)
        {
            bool isDelete = false;
            try
            {
                command.CommandText = "FIS_14_NOV.usp_DeleteWorkHistory";
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@WorkHistoryID", WorkHistoryID);

                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }
        public WorkHistory SearchWorkHistoryDAL(int WorkHistoryID)
        {
            WorkHistory searchWorkHistory = null;
            try
            {
                command.CommandText = "[FIS_14_NOV].[usp_SearchWorkHistory]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@WorkHistoryID", WorkHistoryID);

                SqlDataReader ObjSqlDataReader;
                connection.Open();
                ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    while (ObjSqlDataReader.Read())
                    {
                        searchWorkHistory = new WorkHistory();
                        searchWorkHistory.WorkHistoryID = ObjSqlDataReader.GetInt32(0);
                        searchWorkHistory.FacultyID = ObjSqlDataReader.GetInt32(1);
                        searchWorkHistory.Organization = ObjSqlDataReader.GetString(2);
                        searchWorkHistory.JobTitle = ObjSqlDataReader.GetString(3);
                        searchWorkHistory.JobBeginDate = ObjSqlDataReader.GetDateTime(4);
                        searchWorkHistory.JobEndDate = ObjSqlDataReader.GetDateTime(5);
                        searchWorkHistory.JobResponsibilities = ObjSqlDataReader.GetString(6);
                        searchWorkHistory.JobType = ObjSqlDataReader.GetString(7);
                    }
                }
                ObjSqlDataReader.Close();
               // connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return searchWorkHistory;
        }

        public DataTable GetAllWorkDAL(int facultyId)
        {
            WorkHistory workHistory = new WorkHistory();
            DataTable table = new DataTable();
            try
            {
                command.CommandText = "[FIS_14_NOV].[usp_ViewWorkHistory]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@facultyID", facultyId);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                table.Load(reader);
                

               // connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }

        public DataTable GetAllCourseTaughtDAL(int facultyId)
        {
           
            DataTable table = new DataTable();
            try
            {
                command = new SqlCommand();
                command.CommandText = "[FIS_14_NOV].[usp_ViewCourseTaught]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@facultyID", facultyId);
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                table.Load(reader);


               // connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }
        public bool AddCoursesTaughtDAL(CoursesTaughtEntity coursesTaught)
        {
            bool isAdded = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_AddCoursesTaught";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();
                
                command.Parameters.AddWithValue("@CourseID", coursesTaught.CourseID);
                command.Parameters.AddWithValue("@FacultyID", coursesTaught.FacultyID);
                command.Parameters.AddWithValue("@SubjectID", coursesTaught.SubjectID);
                command.Parameters.AddWithValue("@FirstDateTaught", coursesTaught.FirstDateTaught);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isAdded = NoOfRowsAffected == 1;
            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }

        public bool UpdateCoursesTaughtDAL(CoursesTaughtEntity coursesTaught)
        {
            bool isUpdate = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_UpdateCoursesTaught";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();

                command.Parameters.AddWithValue("@CourseTaughtID", coursesTaught.CourseTaughtID);
                command.Parameters.AddWithValue("@CourseID", coursesTaught.CourseID);
                command.Parameters.AddWithValue("@FacultyID", coursesTaught.FacultyID);
                command.Parameters.AddWithValue("@SubjectID", coursesTaught.SubjectID);
                command.Parameters.AddWithValue("@FirstDateTaught", coursesTaught.FirstDateTaught);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }

        public bool DeleteCoursesTaughtDAL(int CourseTaughtID)
        {
            bool isDelete = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_DeleteCoursesTaught";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@CourseTaughtID", CourseTaughtID);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isDelete = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }


        public FISEntity.CoursesTaughtEntity SearchCoursesTaughtDAL(int searchCourseTaughtID)
        {
            FISEntity.CoursesTaughtEntity searchCourseTaught = null;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_SearchCoursesTaught";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@CourseTaughtID", searchCourseTaughtID);
                command.Connection = connection;
                connection.Open();
                SqlDataReader ObjSqlDataReader = command.ExecuteReader();
                if (ObjSqlDataReader.HasRows)
                {
                    ObjSqlDataReader.Read();
                    searchCourseTaught = new FISEntity.CoursesTaughtEntity();
                    searchCourseTaught.CourseTaughtID = ObjSqlDataReader.GetInt32(0);
                    searchCourseTaught.CourseID = ObjSqlDataReader.GetInt32(1);
                    searchCourseTaught.FacultyID = ObjSqlDataReader.GetInt32(2);
                    searchCourseTaught.SubjectID = ObjSqlDataReader.GetInt32(3);
                    searchCourseTaught.FirstDateTaught = ObjSqlDataReader.GetDateTime(4);
                }
                ObjSqlDataReader.Close();
                //connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return searchCourseTaught;
        }

        public bool AddGrant(GrantsEntity grant)
        {
            bool isAdded = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_AddGrant";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();


                command.Parameters.AddWithValue("@FacultyID", grant.FacultyID);
                command.Parameters.AddWithValue("@GrantTitle", grant.GrantTitle);
                command.Parameters.AddWithValue("@GrantDescription", grant.GrantDescription);

                command.Connection = connection;


                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();


                isAdded = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isAdded;
        }
        public bool UpdateGrant(GrantsEntity grant)
        {
            bool isUpdate = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_UpdateGrant";
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Clear();
                command.Parameters.AddWithValue("@GrantID", grant.GrantID);
                command.Parameters.AddWithValue("@FacultyID", grant.FacultyID);
                command.Parameters.AddWithValue("@GrantTitle", grant.GrantTitle);
                command.Parameters.AddWithValue("@GrantDescription", grant.GrantDescription);
                command.Connection = connection;
                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                isUpdate = NoOfRowsAffected == 1;

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isUpdate;
        }
        public bool DeleteGrant(int grantID)
        {
            bool isDelete = false;
            try
            {
                command = new SqlCommand();
                command.CommandText = "FIS_14_NOV.usp_DeleteGrant";
                command.Connection = connection;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Clear();
                command.Parameters.AddWithValue("@GrantID", grantID);

                connection.Open();
                int NoOfRowsAffected = command.ExecuteNonQuery();

                if (NoOfRowsAffected == 1)
                {
                    isDelete = true;
                }
                else
                {
                    throw new FISException.FISException("Grant Not Exist");
                }
            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isDelete;
        }
        public GrantsEntity SearchGrant(int GrantId)
        {
            GrantsEntity grants = new GrantsEntity();
            String Query = "FIS_14_NOV.usp_SearchGrant";
            SqlCommand command = new SqlCommand(Query, connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@GrantID", GrantId);
            try
            {
                connection.Open();
                SqlDataReader Reader = command.ExecuteReader();
                if (Reader.HasRows)
                {

                    while (Reader.Read())
                    {
                        grants.GrantID = int.Parse(Reader[0].ToString());
                        grants.FacultyID = int.Parse(Reader[1].ToString());

                        grants.GrantTitle = Reader[2].ToString();
                        grants.GrantDescription = Reader[3].ToString();

                    }
                }

            }
            catch (SqlException Exception)
            {
                throw new FISException.FISException(Exception.Message.ToString());


            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message.ToString());


            }
            catch (Exception Exception)
            {
                throw new FISException.FISException(Exception.Message.ToString());

            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return grants;


        }

        public DataTable GetAllGrantsDAL(int facultyID)
        {
            DataTable table = new DataTable();
            try
            {
                command.CommandText = "[FIS_14_NOV].[usp_ViewGrants]";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.Parameters.AddWithValue("@facultyID", facultyID);
                command.Connection = connection;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                table.Load(reader);

               // connection.Close();
            }
            catch (SqlException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (FISException.FISException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (Exception Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            finally
            {
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return table;
        }

    }
}

