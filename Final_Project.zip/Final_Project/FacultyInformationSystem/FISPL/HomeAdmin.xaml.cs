﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for HomeAdmin.xaml
    /// </summary>
    public partial class HomeAdmin : Page
    {
        public HomeAdmin()
        {
            InitializeComponent();
        }

        private void btn_CreateUser_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("CreateUser.xaml", UriKind.RelativeOrAbsolute));

        }

        private void btn_ViewPublications_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("ViewPublication.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btn_WorkInfo_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("WorkInformation.xaml", UriKind.RelativeOrAbsolute));

        }

        private void btn_Courses_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("Courses.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btn_Subjects_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("Subjects.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btn_Dept_Click(object sender, RoutedEventArgs e)
        {
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("Department.xaml", UriKind.RelativeOrAbsolute));

        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            //FISBLL.FISBLL fISBLL = new FISBLL.FISBLL();
            if (Application.Current.Resources["username"] != null)
            {
                tbWelcome.Text = "Welcome " + Application.Current.Resources["username"].ToString();
                
            }
            else
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
        }
    }
}
