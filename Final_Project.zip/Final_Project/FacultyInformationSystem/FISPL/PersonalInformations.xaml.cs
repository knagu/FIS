﻿using FISBLL;
using FISEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for PersonalInformations.xaml
    /// </summary>
    public partial class PersonalInformations : Page
    {
        public PersonalInformations()
        {
            InitializeComponent();
        }
        FISBLL.FISBLL facultyBLL = new FISBLL.FISBLL();
       
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool Added = false;
                FacultyEntity facultyEntity = new FacultyEntity();
                //publicationsEntity.FacultyID = int.Parse(txtfid.Text);
                facultyEntity.UserName = txtUsername.Text;
                facultyEntity.FirstName = txtFirstName.Text;
                facultyEntity.LastName = txtLastName.Text;
                facultyEntity.Address = txtAddress.Text;
                facultyEntity.City = txtCity.Text;
                facultyEntity.State = txtState.Text;
                facultyEntity.Pincode = int.Parse(txtPin.Text);
                facultyEntity.MobileNo = Int64.Parse(txtMobileNo.Text);
                facultyEntity.HireDate = Convert.ToDateTime(dpHireDate.Text);
                facultyEntity.EmailAddress = txtEmail.Text;
                facultyEntity.DateOfBirth = Convert.ToDateTime(dpDateOfBirth.Text);
                facultyEntity.DeptID = int.Parse(txtDeptId.Text);
                facultyEntity.DesignationID = int.Parse(txtDesignationID.Text);
                Added = facultyBLL.AddFacultyBLL(facultyEntity);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    LoadGrid();

                }
                else
                    MessageBox.Show("Not Added");
            }
            catch(FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please fill all the fields");
            }
        }



        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchfaculty = int.Parse(txtfid.Text);
                string userName = Application.Current.Resources["username"].ToString();
                FacultyEntity faculty = facultyBLL.SearchFacultyBLL(searchfaculty, userName);
                if (faculty != null)
                {
                    txtUsername.Text = faculty.UserName;
                    txtFirstName.Text = faculty.FirstName;
                    txtLastName.Text = faculty.LastName;
                    txtAddress.Text = faculty.Address;
                    txtCity.Text = faculty.City;
                    txtState.Text = faculty.State;
                    txtPin.Text = faculty.Pincode.ToString();
                    txtMobileNo.Text = faculty.MobileNo.ToString();
                    dpHireDate.Text = faculty.HireDate.ToString();
                    txtEmail.Text = faculty.EmailAddress.ToString();
                    dpDateOfBirth.Text = faculty.DateOfBirth.ToString();
                    txtDeptId.Text = faculty.DeptID.ToString();
                    txtDesignationID.Text = faculty.DesignationID.ToString();
                }
                else
                {
                    MessageBox.Show("Faculty not Found");
                }
            }
            catch(FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please Enter the faculty Id");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int facId = int.Parse(txtfid.Text);
                bool deleteFaculty = facultyBLL.DeleteFacultyBLL(facId);
                if (deleteFaculty)
                {
                    MessageBox.Show("Deleted successfully");
                    LoadGrid();
                }
                else
                {
                    MessageBox.Show("Something Went Wrong");
                }
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please Enter the faculty Id");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool updated = false;
                int searchfaculty = int.Parse(txtfid.Text);
                string userName = Application.Current.Resources["username"].ToString();
                FacultyEntity faculty = facultyBLL.SearchFacultyBLL(searchfaculty, userName);
                if (faculty != null)
                {
                    faculty.UserName = txtUsername.Text;
                    faculty.FirstName = txtFirstName.Text;
                    faculty.LastName = txtLastName.Text;
                    faculty.Address = txtAddress.Text;
                    faculty.City = txtCity.Text;
                    faculty.State = txtState.Text;
                    faculty.Pincode = int.Parse(txtPin.Text);
                    faculty.MobileNo = Int64.Parse(txtMobileNo.Text);
                    faculty.HireDate = Convert.ToDateTime(dpHireDate.Text);
                    faculty.EmailAddress = txtEmail.Text;
                    faculty.DateOfBirth = Convert.ToDateTime(dpDateOfBirth.Text);
                    faculty.DeptID = int.Parse(txtDeptId.Text);
                    faculty.DesignationID = int.Parse(txtDesignationID.Text);
                }
                updated = facultyBLL.UpdateFacultyBLL(faculty);
                if (updated == true)
                {
                    MessageBox.Show("Updated Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Something Went Wrong");
            }
            catch (FISException.FISException fe)
            {
                MessageBox.Show(fe.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please fill all the fields");
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            
          
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
                txtUsername.Text = Application.Current.Resources["username"].ToString();
              
            }
            
          
        }
        public void LoadGrid()
        {
            DataTable table = new DataTable();
            table = facultyBLL.GetAllFacultyBL(Application.Current.Resources["username"].ToString());
            datagrid.DataContext = table;
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
