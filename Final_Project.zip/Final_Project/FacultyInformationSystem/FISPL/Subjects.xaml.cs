﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FISBLL;
using FISEntity;
using FISException;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for Subjects.xaml
    /// </summary>
    public partial class Subjects : Page
    {
        
        public Subjects()
        {
            InitializeComponent();
        }
        AdminBLL subjectsBLL = new AdminBLL();
        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            SubjectEntity subject = new SubjectEntity();
            bool Added = false;
            try
            {
                //subject.SubjectID = int.Parse(txtSubjectId.Text);
                subject.SubjectName = txtSubjectName.Text;
                

                Added = subjectsBLL.AddSubjectsBLL(subject);
                if (Added == true)
                {
                    MessageBox.Show("Added Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Not Added");
            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {

            int subjectId = int.Parse(txtSubjectId.Text);
            bool deleteSubject = subjectsBLL.DeleteSubjectsBLL(subjectId);
            if (deleteSubject)
            {
                MessageBox.Show("Deleted successfully");
                LoadGrid();
            }
            else
            {
                MessageBox.Show("Something Went Wrong");
            }
            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please enter subject id");
            }
        }

        private void btn_Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool updated = false;
                int updateSubject = int.Parse(txtSubjectId.Text);
                SubjectEntity subject = subjectsBLL.SearchSubjectBLL(updateSubject);
                if (subject != null)
                {

                    subject.SubjectID = int.Parse(txtSubjectId.Text);
                    subject.SubjectName = txtSubjectName.Text;


                }
                updated = subjectsBLL.UpdateSubjectsBLL(subject);
                if (updated == true)
                {
                    MessageBox.Show("Updated Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Something Went Wrong");
            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        public void LoadGrid()
        {
            try
            {
                DataTable table = new DataTable();
                
                table = subjectsBLL.GetAllSubjectsBL();
                datagrid.DataContext = table;
            }
            catch (Exception ex) { }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
            }
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchSubject = int.Parse(txtSubjectId.Text);
                SubjectEntity subject = subjectsBLL.SearchSubjectBLL(searchSubject);
                if (subject != null)
                {
                    txtSubjectId.Text = subject.SubjectID.ToString();
                    txtSubjectName.Text = subject.SubjectName;

                }
                else
                {
                    MessageBox.Show("Subject not Found");
                }
            }
            catch (FISException.FISException Exception)
            {
                MessageBox.Show(Exception.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please enter subject id");
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
