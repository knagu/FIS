﻿using FISBLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FISPL
{
    /// <summary>
    /// Interaction logic for WorkInformation.xaml
    /// </summary>
    public partial class WorkInformation : Page
    {
        public WorkInformation()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Resources["username"] == null)
            {
                NavigationService nav = NavigationService.GetNavigationService(this);
                nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
            }
            else
            {
                LoadGrid();
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            bool updated = false;
            try
            {
                int updateWork = int.Parse(txtWorkid.Text);
                FISEntity.WorkHistory workhistory = adminBLL.SearchWorkHistoryBL(updateWork);
                if (workhistory != null)
                {

                    workhistory.FacultyID = int.Parse(txtFacultyId.Text);
                    workhistory.Organization = txtOrganization.Text;
                    workhistory.JobTitle = txtJobTitle.Text;
                    workhistory.JobBeginDate = Convert.ToDateTime(txtJobBegin.Text);
                    workhistory.JobEndDate = Convert.ToDateTime(txtJobEnd.Text);
                    workhistory.JobResponsibilities = txtJobResponsibilities.Text;
                    workhistory.JobType = txtJobtype.Text;

                }
                updated = adminBLL.UpdateWorkHistoryBL(workhistory);
                if (updated == true)
                {
                    MessageBox.Show("Updated Successfully");
                    LoadGrid();
                }
                else
                    MessageBox.Show("Something Went Wrong");
            }
            catch(FISException.FISException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Please enter required fields");
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchfaculty = int.Parse(txtWorkid.Text);
                FISEntity.WorkHistory workhistory = adminBLL.SearchWorkHistoryBL(searchfaculty);
                if (workhistory != null)
                {
                    txtFacultyId.Text = workhistory.FacultyID.ToString();
                    txtOrganization.Text = workhistory.Organization;
                    txtJobTitle.Text = workhistory.JobTitle;
                    txtJobBegin.Text = workhistory.JobBeginDate.ToString();
                    txtJobEnd.Text = workhistory.JobEndDate.ToString();
                    txtJobResponsibilities.Text = workhistory.JobResponsibilities;
                    txtJobtype.Text = workhistory.JobType;
                }
                else
                {
                    MessageBox.Show("WorkHistory not Found");
                }
            }
            catch (FISException.FISException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("please enter ID");
            }
        }
        AdminBLL adminBLL = new AdminBLL();

        public void LoadGrid()
        {
            DataTable table = new DataTable();

            table = adminBLL.GetAllWorkHistoryBL();
            datagrid.DataContext = table;
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Resources["username"] = null;
            NavigationService nav = NavigationService.GetNavigationService(this);
            nav.Navigate(new Uri("LoginPage.xaml", UriKind.RelativeOrAbsolute));
        }
    }
}
