﻿using FISDAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FISBLL
{
   public class StudentBLL
    {
        StudentDAL studentDAL = new StudentDAL();
        public DataSet GetFacultyNameBLL()
        {
            DataSet ds = studentDAL.GetFacultyNameDAL();
            return ds;
        }
        public DataSet GetPublicationTitleBLL(string selectedvalue)
        {
            DataSet ds = studentDAL.GetPublicationTitleDAL(selectedvalue);
            return ds;
        }
        public DataTable ShowPublicationBLL(string selectedvalue)
        {
            DataTable dt = studentDAL.ShowPublicationDAL(selectedvalue);
            return dt;
        }
    }
}
