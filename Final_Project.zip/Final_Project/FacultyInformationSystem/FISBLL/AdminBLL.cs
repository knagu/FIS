﻿using FISDAL;
using FISEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FISBLL
{
    public class AdminBLL
    {
        AdminDAL adminDAL = new AdminDAL();
        //User Validation
        private bool ValidateUser(FISEntity.UserEntity User)
        {
            StringBuilder sb = new StringBuilder();
            bool validateUser = true;
            if (User.UserName == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "User Name Required");
            }
            if (User.Password.Length < 8)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "Password should not be less than 8 characters");
            }
            if (User.UserType == string.Empty)
            {
                validateUser = false;
                sb.Append(Environment.NewLine + "UserType is Required");
            }
            if (validateUser == false)
                throw new FISException.FISException(sb.ToString());
            return validateUser;

        }
        //Work Information Validations
        private bool ValidateWorkHistory(FISEntity.WorkHistory WorkHistory)
        {
            StringBuilder sb = new StringBuilder();
            bool validateWorkHistory = true;

            if (WorkHistory.Organization == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "Organization Required");
            }
            if (WorkHistory.JobTitle == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "JobTitle Required");
            }
            if (Convert.ToDateTime(WorkHistory.JobBeginDate.ToString().Substring(0, 10)) > Convert.ToDateTime(DateTime.Now.ToString().Substring(0, 10)))
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "Invalid job begin Date");
            }
            if (Convert.ToDateTime(WorkHistory.JobEndDate.ToString().Substring(0, 10)) <= Convert.ToDateTime(WorkHistory.JobBeginDate.ToString().Substring(0, 10)))
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "Invalid job end Date");
            }
            if (WorkHistory.JobResponsibilities == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "JobResponsibilities Required");
            }
            if (WorkHistory.JobType == string.Empty)
            {
                validateWorkHistory = false;
                sb.Append(Environment.NewLine + "JobType Required");
            }
            if (validateWorkHistory == false)
                throw new FISException.FISException(sb.ToString());
            return validateWorkHistory;
        }

        //Subjects validation
        private bool ValidateSubject(FISEntity.SubjectEntity Subject)
        {
            StringBuilder sb = new StringBuilder();
            bool validateSubject = true;
            if (Subject.SubjectName == string.Empty)
            {
                validateSubject = false;
                sb.Append(Environment.NewLine + "Subject Name Required");
            }

            if (validateSubject == false)
                throw new FISException.FISException(sb.ToString());
            return validateSubject;
        }

        private bool ValidateDepartment(FISEntity.DepartmentEntity department)
        {
            StringBuilder sb = new StringBuilder();
            bool validateSubject = true;
            if (department.DeptName == string.Empty)
            {
                validateSubject = false;
                sb.Append(Environment.NewLine + "Department Name Required");
            }

            if (validateSubject == false)
                throw new FISException.FISException(sb.ToString());
            return validateSubject;
        }
        //validations for view publications
        private bool ValidatePublications(string date)
        {
            StringBuilder sb = new StringBuilder();
            bool validateSubject = true;
            if (date == string.Empty)
            {
                validateSubject = false;
                sb.Append(Environment.NewLine + "Please enter year");
            }

            if (validateSubject == false)
                throw new FISException.FISException(sb.ToString());
            return validateSubject;
        }

        //courses validations

        private bool ValidateCourses(FISEntity.CoursesEntity Courses)
        {
            StringBuilder sb = new StringBuilder();
            bool validateCourses = true;
            if (Courses.CourseName == string.Empty)
            {
                validateCourses = false;
                sb.Append(Environment.NewLine + "Course Name Required");
            }
            if (Courses.CourseCredits <= 0)
            {
                validateCourses = false;
                sb.Append(Environment.NewLine + "Course Credits is Required");
            }
            if (Courses.DeptID.ToString() == string.Empty)
            {
                validateCourses = false;
                sb.Append(Environment.NewLine + "Dept ID is Required");
            }
            if (validateCourses == false)
                throw new FISException.FISException(sb.ToString());
            return validateCourses;

        }
        public bool AddUser(FISEntity.UserEntity User)
        {
            bool isAdded = false;
            try
            {
                if (ValidateUser(User))
                {
                    isAdded = adminDAL.AddUserDAL(User);
                }
            }

            catch (FISException.FISException ex)
            {
                throw new FISException.FISException(ex.Message);
            }
            return isAdded;

        }
        public List<FacultyEntity> ViewAllFacultyBLL()
        {

            List<FacultyEntity> ObjFacultyList = new List<FacultyEntity>();
            try
            {
                ObjFacultyList = adminDAL.ViewAllFaculty();

            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return ObjFacultyList;

        }
        //public bool AddDepartmentsBLL(DepartmentEntity department)
        //{
        //    bool isAdded = false;
        //    try
        //    {
        //        isAdded = adminDAL.AddDepartments(department);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    return isAdded;

        //}

        //public bool UpdateDepartmentsBLL(DepartmentEntity department)
        //{
        //    bool isUpdated = false;
        //    try
        //    {
        //        isUpdated = adminDAL.UpdateDepartments(department);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    return isUpdated;

        //}

        //public bool DeleteDepartmentsBLL(int departmentId)
        //{
        //    bool isDeleted = false;
        //    try
        //    {
        //        isDeleted = adminDAL.DeleteDepartments(departmentId);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    return isDeleted;

        //}
        //public bool AddCoursesBLL(CoursesEntity courses)
        //{
        //    bool isAdded = false;
        //    try
        //    {
        //        isAdded = adminDAL.AddCourses(courses);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    return isAdded;

        //}

        public bool UpdateDepartmentsBLL(CoursesEntity courses)
        {
            bool isUpdated = false;
            try
            {
                isUpdated = adminDAL.UpdateCourses(courses);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isUpdated;

        }

        //public bool DeleteCoursesBLL(int courseId)
        //{
        //    bool isDeleted = false;
        //    try
        //    {
        //        isDeleted = adminDAL.DeleteCourses(courseId);
        //    }
        //    catch (FISException.FISException Exception)
        //    {
        //        throw new FISException.FISException(Exception.Message);
        //    }
        //    return isDeleted;

        //}
        public bool AddDesignationBLL(DesignationEntity designation)
        {
            bool isAdded = false;
            try
            {
                isAdded = adminDAL.AddDesignation(designation);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isAdded;

        }

        public bool UpdateDesignationBLL(DesignationEntity designation)
        {
            bool isUpdated = false;
            try
            {
                isUpdated = adminDAL.UpdateDesignation(designation);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isUpdated;

        }

        public bool DeleteDesignationBLL(int designationId)
        {
            bool isDeleted = false;
            try
            {
                isDeleted = adminDAL.DeleteDesignation(designationId);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isDeleted;

        }
        public bool AddSubjectsBLL(SubjectEntity subject)
        {
            bool isAdded = false;
            try
            {
                if (ValidateSubject(subject))
                {
                    isAdded = adminDAL.AddSubjects(subject);
                }
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isAdded;

        }

        public SubjectEntity SearchSubjectBLL(int searchSubjectID)
        {
            SubjectEntity searchSubject = null;
            try
            {
                
                searchSubject = adminDAL.SearchSubjectDAL(searchSubjectID);
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchSubject;

        }

        public bool UpdateSubjectsBLL(SubjectEntity subject)
        {
            bool isUpdated = false;
            try
            {
                if (ValidateSubject(subject))
                {
                    isUpdated = adminDAL.UpdateSubjects(subject);
                }
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isUpdated;

        }

        public DataTable GetAllSubjectsBL()
        {
            DataTable table = null;
            try
            {
                //FISDAL.FacultyDAL faculty = new FISDAL.FacultyDAL();
                table = adminDAL.GetAllSubjectsDAL();
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }

        public bool DeleteSubjectsBLL(int subjectId)
        {
            bool isDeleted = false;
            try
            {
                isDeleted = adminDAL.DeleteSubjects(subjectId);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isDeleted;

        }

        public List<PublicationsEntity> ViewPublicationsBLL()
        {
            List<PublicationsEntity> lstPublications = new List<PublicationsEntity>();

            try
            {
                lstPublications = adminDAL.ViewPublications();

            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }

            return lstPublications;
        }
        public List<PublicationsEntity> ViewPublicationsByYearBLL(string year)
        {
            List<PublicationsEntity> lstPublications = new List<PublicationsEntity>();

            try
            {
                if (ValidatePublications(year))
                {
                    lstPublications = adminDAL.ViewPublicationsByYearDAL(year);
                }
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }

            return lstPublications;
        }
        public FISEntity.WorkHistory SearchWorkHistoryBL(int searchWorkHistoryID)
        {
            FISEntity.WorkHistory searchWorkHistory = null;
            try
            {

                searchWorkHistory = adminDAL.SearchWorkHistoryDAL(searchWorkHistoryID);
            }
            catch (FISException.FISException ex)
            {
                throw new FISException.FISException("enter ID");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchWorkHistory;

        }

        public bool UpdateWorkHistoryBL(FISEntity.WorkHistory updateWorkHistory)
        {
            bool WorkHistoryUpdated = false;
            try
            {
                if (ValidateWorkHistory(updateWorkHistory))
                {

                    WorkHistoryUpdated = adminDAL.UpdateWorkInformation(updateWorkHistory);
                 }
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return WorkHistoryUpdated;
        }
        public DataTable GetAllWorkHistoryBL()
        {
            DataTable table = new DataTable();
            try
            {
                //FISDAL.WorkHistoryDAL workHistory = new FISDAL.WorkHistoryDAL();
                table = adminDAL.GetAllWorkDAL();
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }
        public bool AddCoursesBLL(CoursesEntity courses)
        {
            bool isAdded = false;
            try
            {
                if (ValidateCourses(courses))
                {
                    isAdded = adminDAL.AddCourses(courses);
                }
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isAdded;

        }

        public bool UpdateCoursesBLL(CoursesEntity courses)
        {
            bool isUpdated = false;
            try
            {
                if (ValidateCourses(courses))
                {
                    isUpdated = adminDAL.UpdateCourses(courses);
                }
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isUpdated;

        }

        public DataTable GetAllCoursesBLL()
        {
            DataTable table = new DataTable();
            try
            {
                table = adminDAL.GetAllCoursesDAL();
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;
        }

        public bool DeleteCoursesBLL(int courseId)
        {
            bool isDeleted = false;
            try
            {
                isDeleted = adminDAL.DeleteCourses(courseId);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException("enter ID");
            }
            return isDeleted;
        }

        public CoursesEntity SearchCoursesBLL(int searchCoursesID)
        {
            CoursesEntity searchCourse = null;
            try
            {

                searchCourse = adminDAL.SearchCoursesDAL(searchCoursesID);
            }
            catch (FISException.FISException ex)
            {
                throw new FISException.FISException("enter ID");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCourse;

        }

        public bool AddDepartmentsBLL(DepartmentEntity department)
        {
            bool isAdded = false;
            try
            {
                isAdded = adminDAL.AddDepartments(department);
            }
            catch (FISException.FISException Exception)
            {
                throw new FISException.FISException(Exception.Message);
            }
            return isAdded;

        }
        public DataTable ViewAllDepartmentBLL()
        {
            DataTable table = null;
            try
            {
                //FISDAL.FacultyDAL faculty = new FISDAL.FacultyDAL();
                table = adminDAL.GetAllDepartmentDAL();
            }
            catch (FISException.FISException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return table;

        }
    }
}
