﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FISEntity
{
    public class UserEntity
    {

        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string UserType { get; set; }
    }

    public class FacultyEntity
    {
        public int FacultyID { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Pincode { get; set; }
        public Int64 MobileNo { get; set; }
        public DateTime HireDate { get; set; }
        public string EmailAddress { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int DeptID { get; set; }
        public int DesignationID { get; set; }


    public WorkHistory workHistories { get; set; }
    }

    public class PublicationsEntity
    {
        public int PublicationID { get; set; }
        public int FacultyID { get; set; }
        public string PublicationTitle { get; set; }
        public string ArticleName { get; set; }
        public string PublisherName { get; set; }
        public string PublicationLocation { get; set; }
        public DateTime CitationDate { get; set; }
    }

    public class WorkHistory
    {
        public int WorkHistoryID { get; set; }
        public int FacultyID { get; set; }
        public string Organization { get; set; }
        public string JobTitle { get; set; }
        public DateTime JobBeginDate { get; set; }
        public DateTime JobEndDate { get; set; }
        public string JobResponsibilities { get; set; }
        public string JobType { get; set; }
    }

    //public class DegreesEntity
    //{
    //    public int DegreeID { get; set; }
    //    public int FacultyID { get; }
    //    public string Degree { get; set; }
    //    public string Specialization { get; set; }
    //    public int DegreeYear { get; set; }
    //    public char Grade { get; set; }
    //}

    public class GrantsEntity
    {
        public int GrantID { get; set; }
        public int FacultyID { get; set; }
        public string GrantTitle { get; set; }
        public string GrantDescription { get; set; }
    }

    public class CoursesEntity
    {
        public int CourseID { get; set; }
        public string CourseName { get; set; }
        public int CourseCredits { get; set; }
        public int DeptID { get; set; }
    }

    public class DepartmentEntity
    {
        public int DeptID { get; set; }
        public string DeptName { get; set; }
    }

    public class DesignationEntity
    {
        public int DesignationID { get; set; }
        public string DesignationName { get; set; }
    }

    public class SubjectEntity
    {
        public int SubjectID { get; set; }
        public string SubjectName { get; set; }
    }

    //public class CourseSubject
    //{
    //    public int CourseID { get; }
    //    public int SubjectID { get; }
    //}

    public class CoursesTaughtEntity
    {
        public int CourseTaughtID { get; set; }
        public int CourseID { get; set; }
        public int FacultyID { get; set; }
        public int SubjectID { get; set; }
        public DateTime FirstDateTaught { get; set; }
    }
}
